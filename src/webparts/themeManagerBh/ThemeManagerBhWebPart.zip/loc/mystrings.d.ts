declare interface IThemeManagerBhWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ThemeManagerBhWebPartStrings' {
  const strings: IThemeManagerBhWebPartStrings;
  export = strings;
}
