/* tslint:disable */
require('./ThemeManagerBhWebPart.module.css');
const styles = {
  themeManagerBh: 'themeManagerBh_35baddfa',
  container: 'container_35baddfa',
  row: 'row_35baddfa',
  column: 'column_35baddfa',
  'ms-Grid': 'ms-Grid_35baddfa',
  title: 'title_35baddfa',
  subTitle: 'subTitle_35baddfa',
  description: 'description_35baddfa',
  button: 'button_35baddfa',
  label: 'label_35baddfa',
};

export default styles;
/* tslint:enable */